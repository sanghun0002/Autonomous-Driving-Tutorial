# CARLA Ackermann Control

Find documentation about the CARLA Ackermann Control package [__here__](https://carla.readthedocs.io/projects/ros-bridge/en/latest/carla_ackermann_control/).
