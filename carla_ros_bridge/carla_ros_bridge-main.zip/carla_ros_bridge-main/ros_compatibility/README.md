# ROS compatibility node

Find documentation about the CARLA ROS compatibility node [__here__](https://carla.readthedocs.io/projects/ros-bridge/en/latest/ros_compatibility/).